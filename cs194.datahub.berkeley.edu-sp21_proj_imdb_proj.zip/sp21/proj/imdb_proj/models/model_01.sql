{{ config(materialized='view') }}

SELECT a.id, a.name, a.gender, c.movie_id 
  FROM {{ source("imdb", "cast_sample") }} c left join {{ source("imdb", "actor_sample") }} a on c.person_id = a.id 
  
