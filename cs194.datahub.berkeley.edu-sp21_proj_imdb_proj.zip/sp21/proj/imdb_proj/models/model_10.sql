{{ config(materialized='view') }}


select j.*, mis3.info, 
(regexp_match(mis3.info, '\s(\S*)\s'))[1] as mpaa_rating, 
round(length(mis3.info) - length(replace(mis3.info, 'sex', '')))/length('sex') as count_sex
FROM {{ source("imdb", "movie_info_sample") }} mis3, {{ ref("model_09") }} j
WHERE mis3.info_type_id = 97 AND mis3.movie_id = j.movie_id
