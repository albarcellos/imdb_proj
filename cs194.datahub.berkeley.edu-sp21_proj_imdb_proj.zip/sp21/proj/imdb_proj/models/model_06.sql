{{ config(materialized='view') }}


select g.movie_id as movie_id, g.title as title, gross, budget, (gross - budget) as profit
FROM {{ ref("model_04") }} g, {{ ref("model_05") }} b
WHERE g.movie_id = b.movie_id