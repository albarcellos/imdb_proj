{{ config(materialized='view') }}

SELECT movie_id, round(avg(Case when Gender = 'm' then 0 else 1 end)*100, 2) as percent_female
  FROM {{ ref("model_01") }} 
  GROUP BY movie_id