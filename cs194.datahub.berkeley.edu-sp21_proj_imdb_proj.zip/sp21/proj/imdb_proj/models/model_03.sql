{{ config(materialized='view') }}

select * from 
{{ source("imdb", "movie_sample") }} m inner join {{ ref("model_02") }} f on m.id = f.movie_id