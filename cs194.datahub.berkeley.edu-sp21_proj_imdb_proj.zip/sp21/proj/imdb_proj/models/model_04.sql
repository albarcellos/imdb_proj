{{ config(materialized='view') }}


select mis.movie_id as movie_id, max(cast((regexp_replace(((regexp_match(mis.info, '\$(\S*)'))[1]), '(,)', '', 'g')) as float)) as gross, max(title) as title 
FROM {{ source("imdb", "movie_info_sample") }} mis, {{ source("imdb", "movie_sample") }} ms
WHERE info_type_id = 107
AND info like '%(USA)%' AND info like '%$%'
AND mis.movie_id = ms.id
GROUP BY mis.movie_id

