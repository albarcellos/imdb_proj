{{ config(materialized='view') }}


select movie_id, title, gross, budget, profit, production_year, percent_female, Case 
                    when production_year >= 1900
                        AND production_year < 1910 THEN 0
                    when production_year >= 1910
                        AND production_year < 1920 THEN 1
                    when production_year >= 1920
                        AND production_year < 1930 THEN 2
                    when production_year >= 1930
                        AND production_year < 1940 THEN 3
                    when production_year >= 1940
                        AND production_year < 1950 THEN 4
                    when production_year >= 1950
                        AND production_year < 1960 THEN 5
                    when production_year >= 1960
                        AND production_year < 1970 THEN 6
                    when production_year >= 1970
                        AND production_year < 1980 THEN 7
                    when production_year >= 1980
                        AND production_year < 1990 THEN 8
                    when production_year >= 1900
                        AND production_year < 2000 THEN 9
                    when production_year >= 2000
                        AND production_year < 2010 THEN 10
                    when production_year >= 2010 THEN 11
        end year_cat
 
from {{ ref("model_07") }}