{{ config(materialized='view') }}


select max(cast((regexp_replace(((regexp_match(mis2.info, '(\d\S*)'))[1]), '(,)', '', 'g')) as float)) as budget, mis2.movie_id as movie_id, max(ms2.title) as title
FROM {{ source("imdb", "movie_info_sample") }} mis2, {{ source("imdb", "movie_sample") }} ms2
WHERE info_type_id = 105
AND mis2.movie_id = ms2.id
GROUP BY mis2.movie_id

