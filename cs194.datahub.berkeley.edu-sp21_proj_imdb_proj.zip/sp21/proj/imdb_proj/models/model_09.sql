{{ config(materialized='view') }}


select *, avg(percent_female) OVER (PARTITION BY year_cat) as avg_percent_year
FROM {{ ref("model_08") }}