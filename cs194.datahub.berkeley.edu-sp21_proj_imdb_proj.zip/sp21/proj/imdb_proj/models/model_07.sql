{{ config(materialized='view') }}


select g2.movie_id as movie_id, g2.title as title, gross, budget, profit, id, production_year, percent_female
from {{ ref("model_03") }} g2 inner join {{ ref("model_06") }} m3 on g2.movie_id = m3.movie_id